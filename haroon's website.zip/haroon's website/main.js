
    
    // ingredients section

    new Swiper('.ingredients-swiper', {
        slidesPerView: 1,
        spaceBetween: 20,
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
        },
        pagination: {
            el: '.swiper-pagination',
            clickable: true,
        },
        breakpoints: {
            640: {
                slidesPerView: 2,
            },
            768: {
                slidesPerView: 3,
            },
            1024: {
                slidesPerView: 4,
            },
        },
    });




    // nav

        
            function toggleMenu() {
                document.getElementById("nav-links").classList.toggle("active");
            }
        

            // faq

            function toggleBiohealFaq(button) {
                // Close all other FAQs
                const allFaqs = document.querySelectorAll('.bioheal-faq-item');
                allFaqs.forEach(faq => {
                    if (faq !== button.parentElement) {
                        faq.classList.remove('active');
                    }
                });
                
                // Toggle the clicked FAQ
                button.parentElement.classList.toggle('active');
            }

            